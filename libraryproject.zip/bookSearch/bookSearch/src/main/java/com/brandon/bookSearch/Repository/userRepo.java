package com.brandon.bookSearch.Repository;

import com.brandon.bookSearch.Entity.User;
import org.springframework.data.jpa.repository.JpaRepository;

/*
 * @Author Neica 
 */

public interface userRepo extends JpaRepository< User, Long> {

   User findByUserName(String userName);
   
}
