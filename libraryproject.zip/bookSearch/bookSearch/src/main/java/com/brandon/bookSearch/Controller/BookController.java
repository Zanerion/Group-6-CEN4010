package com.brandon.bookSearch.Controller;

import com.brandon.bookSearch.Service.BookService;
import com.brandon.bookSearch.Entity.Book;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("library")
public class BookController {
    private final BookService bookService;

    public BookController(BookService bookService) {
        this.bookService = bookService;
    }

    @GetMapping("allBooks")
    public String getAllBooks() {
        List<Book> books = bookService.getAllBooks();
        StringBuilder sb = new StringBuilder();
        sb.append("<html><head><title>Book List</title></head><body><h1>Book List</h1><ul>");
        for (Book book : books) {
            sb.append("<li>ID: ").append(book.getId()).append("</li>");
            sb.append("<li>Title: ").append(book.getTitle()).append("</li>");
            sb.append("<li>Author: ").append(book.getAuthor()).append("</li><br>");
        }
        sb.append("</ul></body></html>");
        return sb.toString();
    }
}